<?php

    //Database Connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "arimac";

    // Create connection
    $conn = new mysqli('localhost','root','','arimac');
?>
